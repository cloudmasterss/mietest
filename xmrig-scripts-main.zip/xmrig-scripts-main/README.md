# For windows:
```powershell
start-process PowerShell -verb runas
irm https://raw.githubusercontent.com/Lachine1/xmrig-scripts/main/windows.ps1 | iex
```
# For linux:
```bash
curl -fsSL https://raw.githubusercontent.com/Lachine1/xmrig-scripts/main/linux.sh | sh
```
